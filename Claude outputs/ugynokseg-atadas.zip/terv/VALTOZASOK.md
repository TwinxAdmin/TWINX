# VÁLTOZÁSOK (a tervező projekt vezeti; a repóban csak olvasható)

## 2026-11-23 – 2. export az ügynökségnek (döntések: D23–D61)
- Új: `ai-ugynokseg/11-ugynokseg-kovetkezo-feladatok.md` – az ügynökség következő feladatai sorrendben (ezzel kezdj).
- Új a mappában (történeti háttér, a partner ág anyaga, szünetel; a fejlécük jelzi, mi érvénytelen): `ai-ugynokseg/03`, `06`, `07`, `08`.
- Frissült: `ai-ugynokseg/01` (D60: API-költség; D61: az ügynökség adminban való megtekintése parkolt, két adatmodell-előfeltétellel), `25`, `26` (parkolt lista).
- Mit kell újraolvasnia az ügynökségnek: `11`, `01` (D58–D61), és az adatmodellnél a D61 két előfeltétele.

## 2026-11-23 – 1. export (döntések: D23–D59)
- Első teljes export a `docs/terv/` mappának: `00`, `ai-ugynokseg/01`, `04`, `05`, `11`–`26`.
- Új: `26-egyuttmukodes-rendje.md` (D59), `25-atado-uzenetek.md`, `VALTOZASOK.md`, `VISSZAJELZES.md` (sablon).
- A régi `docs/ugynokseg/01-alap-es-szabalyok.md` (D01–D14) elavult; az itteni `ai-ugynokseg/01` váltja.
