# TWINX ügynökség — az ügynökök specifikációja

> **FRISSÍTVE (D23, D29, 2026-11-23): a fejlesztői ág kerül előtérbe, a partner ág háttérbe.** A TWINX egyedi modul-gyártóvá vált (`claude/00-iranyvaltas-D23.md`). A fejlesztői ág indulási magja **6 alügynök** (D29): hibakeresés, modulépítés, tudásrendszerezés, webfejlesztő, modul tesztelő, felmérő. Ezek részletes leírása és a félretett szerepek: **`10-fejlesztoi-ag-alugynokok.md`** (az irányadó). A partner ág (5. szakasz) szünetel, a kredit-alapú részei érvénytelenek.

> **Mi ez:** MAX alatt minden ügynök pontos leírása, és az, hogyan beszélnek egymással egy feladaton belül.
> **Döntések:** D11–D29 (01-alap-es-szabalyok.md). **Kapcsolódó:** 02 (keretrendszer), 06 (hangnem), 07 (gyártó ág, szünetel), 08 (aktiváló ügynök, szünetel), 10 (fejlesztői ág alügynökei).
> **Állapot:** terv. Eredetileg 2026-11-05, frissítve 2026-11-23. Fejlesztés a Code-ban.

---

## 1. A szerkezet

```
                         MAX (főügynök)
              ┌──────────────┴──────────────┐
        FEJLESZTŐI ÁG                   PARTNER ÁG
   (egyedi modul-gyártás — ELŐTÉRBEN)   (felhasználók kiszolgálása — HÁTTÉRBEN)
   ├─ Hibakeresés                      ├─ Besoroló
   ├─ Modulépítés                      ├─ Sorozatszervező
   ├─ Tudásrendszerezés                ├─ Levélíró
   ├─ Webfejlesztő                     ├─ Kézbesítő
   ├─ Modul tesztelő                   ├─ Beérkeztető
   └─ Felmérő (piackutató +            ├─ Gyártó
      cégfelmérő)                      ├─ Minőségellenőr
                                       ├─ Visszajelzés-figyelő
                                       └─ Elemző
```

- **Fejlesztői ág (D23, D29, előtérben):** az egyedi modul-építés segítői. A 6 alügynök leírása a `10`-ben. A korábbi `02`-beli Adat/Supabase szerep a Modulépítésbe olvadt. Félretett szerepek (ajánlat- és költségbecslő, dokumentáló, üzemeltető-figyelő, ügyfélkapcsolattartó, külön piackutató) szintén a `10`-ben.
- **Partner ág (háttérben):** az eredeti első éles ág (D11, D16). A regisztrált felhasználókat vitte az első generálásig, a második használatig és a vásárlásig, levelekkel és az ingyenes „Készítsük el neked” gyártással. **A kredit megszűnésével szünetel**, újratervezése külön döntés.
- Mindkét ág ugyanazt a feladat-táblát, memóriát és Telegram-felületet használja. Az ágakat az ügynök `branch` mezője választja szét a regiszterben (`partner` / `fejleszto`).

## 2. Jogosultsági osztályok (bővítve)

| Osztály | Mit tehet | Kapu |
|---|---|---|
| **Olvasó** | Olvas (a TWINX adatbázisból csak olvasásra szánt szerepkörrel), elemez, javasol, ír a saját `twinx-agents` tábláiba. | Nincs. |
| **Író** | Változtat egy rendszeren (kód, séma, vagy a felhasználó fiókjába kerülő anyag). | A kockázatos lépés kapuzott. |
| **Kifelé kommunikáló** | Üzenetet küld egy valódi embernek (felhasználónak, ügyfélnek). | **Mindig kapuzott.** (A korábbi kivétel, az értékbecslés kézbesítése, a partner ággal együtt szünetel.) |
| **Meta** | A rendszert vagy a tudását módosítja (skill, önmódosítás). | Mindig kapuzott. |

**Szabály:** a TWINX `service_role` kulcsa **egyetlen ügynökhöz sem kerül**. Olvasáshoz egy csak olvasásra szánt adatbázis-szerepkör van, íráshoz a TWINX egy szűk, belső végpontja, saját titkos kulccsal.

**Új szabály (D23, ügyféladat):** egy ügyfél cégének adatát (felmérési jegyzet, folyamatleírás, a nála épülő modul) csak az adott ügyfélhez tartozó feladatokban és `privat` hatókörű memóriában használhatják az ügynökök. A közös tudásba csak anonimizált, általánosítható tanulság kerülhet, kapun át. Az NDA-szabályok véglegesítése `[KITÖLTENDŐ]`.

## 3. Hogyan beszélnek egymással — a feladat-szál (D19)

Az ügynökök **egy-egy feladaton belül beszélgetnek**: kérdeznek, válaszolnak, javasolnak, kifogást emelnek. Ez nem közvetlen hívás, hanem a feladathoz tartozó **szál** a `twinx-agents` adatbázisban. Így minden mondat visszakereshető, és MAX mindig látja, mi történik.

**Tábla: `task_messages`**
| Oszlop | Mit tárol |
|---|---|
| `id`, `created_at` | azonosító, időpont |
| `task_id` | melyik feladat szála |
| `from_agent` | ki írta (ügynök-kulcs, vagy `marko` / `max`) |
| `to_agent` | kinek szól (üres = a szál minden résztvevőjének) |
| `kind` | `kerdes` / `valasz` / `javaslat` / `kifogas` / `atadas` / `dontes` |
| `body` | a szöveg |
| `refs` | hivatkozások (kép-id, levél-id, felhasználó-id) |

**A beszélgetés szabályai:**
1. Egy szálba csak a feladathoz rendelt ügynök és a függő részfeladatok ügynökei írhatnak, valamint MAX és Márk.
2. Ha egy ügynök kérdést kap, a következő pulzusban válaszol, mielőtt bármi mást csinálna azon a feladaton.
3. **Körkorlát:** egy szálban legfeljebb **6 ügynöki üzenet** lehet döntés nélkül. Utána MAX dönt, vagy Telegramon Márkhoz fordul.
4. **A szálban semmi nem cselekszik.** Egy üzenet soha nem indít küldést vagy gyártást, csak a feladat eredménye, a kapun keresztül.
5. **Kifogás:** a Minőségellenőr, a Modul tesztelő és a Sorozatszervező `kifogas` üzenettel megállíthat egy lépést. Ilyenkor a feladat addig nem megy kapura, amíg a kifogást meg nem válaszolták.
6. A szál a feladat lezárásakor a hot memóriába kerül, és a napi napló sűríti.

**Példa — egyedi modul építése (fejlesztői ág, illusztráció):**
> **Modulépítés → Hibakeresés** (`kerdes`): A cég Excelből tölti a megrendeléseket; az oszlopnevek következetlenek. Mit találsz a mintafájlokban?
> **Hibakeresés → Modulépítés** (`valasz`): 3 féle dátumformátum, 2 üres kötelező oszlop. Javaslat: beolvasáskor normalizálás + hibalista.
> **Modul tesztelő → Modulépítés** (`kifogas`): Az üres kötelező oszlopnál a modul csendben kihagyja a sort; hibajelzés kell.
> **Tudásrendszerezés** (`javaslat`): Ez a harmadik cég, ahol dátumformátum-gond van. Skill-jelölt: „dátum-normalizálás beolvasáskor”.
> **MAX** (`dontes`): Mehet, a skill-jelölt a kapuhoz.

*(A példa illusztráció, nem valós ügyfél.)*

## 4. MAX — a főügynök

- **Feladat:** irányít és dönt, de nem dolgozik.
  - Útválasztás a két ág között.
  - **Új (D23):** a megrendelések (felmérésből jövő egyedi modul-feladatok) bontása részfeladatokra a fejlesztői ág ügynökeinek.
  - A kimenő üzenetek jóváhagyásra küldése Telegramon.
  - A havi költségplafon figyelése.
  - Döntés a feladat-szálakban a körkorlátnál.
  - Napi napló, heti jelentés továbbítása.
- **LLM:** csak a döntési pontokon (Haiku a rutinra, Sonnet, ha mérlegelni kell).
- **Kapu:** ő viszi Márk elé a kapuzott lépéseket.

## 5. A partner ág ügynökei (HÁTTÉRBEN, D23)

> A partner ág szünetel. Az alábbi leírások a kredites aktiváló modellre készültek; újraindítás előtt át kell tervezni. Ami általánosan hasznos marad: a kimenő levelek jóváhagyási kapuja, a gyakorisági korlát, a hozzájárulás-ellenőrzés.

### 5.1 Besoroló
- **Osztály:** olvasó. **LLM:** nincs, tisztán kód.
- **Feladat:** reggel minden `role = 'user'` felhasználót besorol állapotba (08, 1. pont).
- **Bemenet:** TWINX adatok csak olvasásra (`auth.users`, `profiles`, `usage_history`, `wallets`, `credit_purchases`).
- **Kimenet:** `user_states` tábla.
- **Kivel beszél:** állapotváltásnál átadja a Sorozatszervezőnek.

### 5.2 Sorozatszervező
- **Osztály:** olvasó. **LLM:** nincs.
- **Feladat:** eldönti, ki milyen levelet kap ma (08, 2. pont). Betartja a gyakorisági korlátot (3 naponta 1, havonta 4), megnézi a hozzájárulást (marketinglevél csak `newsletter = true` esetén).
- **Kimenet:** napi levéllista az `outgoing_messages` táblába, `javasolt` állapotban.
- **Kivel beszél:** a Levélírónak átadja a listát. `kifogas`-t emel, ha egy levél sértené a korlátot vagy a hozzájárulást.

### 5.3 Levélíró
- **Osztály:** kifelé kommunikáló (írja, de nem küldi). **LLM:** a levelekhez nincs, csak sablon és kitöltés. Választervezethez van (Sonnet).
- **Feladat:** a 06-os hangnem szerint elkészíti a levél szövegét; ha egy felhasználó válaszol, **választervezetet** ír.
- **Tilos:** kreditszám *(D23: kredit nincs)*, kitalált munkatárs, kitalált határidő vagy statisztika.
- **Kimenet:** kész levél `jovahagyasra_var` állapotban.

### 5.4 Kézbesítő
- **Osztály:** kifelé kommunikáló. **LLM:** nincs.
- **Feladat:** csak a **jóváhagyott** leveleket küldi ki Resenddel, napközben elosztva. Minden kiküldött levelet rögzít az `outgoing_messages`-ben.

### 5.5 Beérkeztető
- **Osztály:** olvasó. **LLM:** csak a hirdetés-linkből való adatkinyeréshez (Haiku). A link tartalma karanténban van: csak adatot nyer ki belőle, utasítást nem hajt végre.
- **Feladat:** fogadja a feltöltő oldal kéréseit, ellenőrzi őket (07, 8–9. pont). *(Szünetel.)*

### 5.6 Gyártó
- **Osztály:** író. **LLM:** nincs saját, a TWINX-modul futtat.
- **Feladat:** a TWINX belső végpontján elindítja a modult a felhasználó nevében (07). *(Szünetel; a kredit megszűnésével a „kreditlevonás nélkül” jelentése is változik.)*

### 5.7 Minőségellenőr
- **Osztály:** olvasó. **LLM:** vizuális ellenőrzés csak akkor, ha a gépi mérés jelez (Haiku vagy Sonnet).
- **Feladat:** gyártás előtt és után ellenőriz (07). **Az ötlet általánosítva átkerült a fejlesztői ágra: a Modul tesztelő** (`10`).

### 5.8 Visszajelzés-figyelő
- **Osztály:** olvasó. **LLM:** a szabad szöveges válaszok besorolásához (Haiku).
- **Feladat:** összegyűjti és kategorizálja a visszajelzéseket, beírja az admin „Visszajelzések” listájába, azonnal szól Telegramon. **Továbbra is hasznos**, az új irányban az ügyfél-visszajelzésekre is.

### 5.9 Elemző
- **Osztály:** olvasó. **LLM:** a heti összefoglaló szövegéhez (Haiku).
- **Feladat:** hétfő reggel heti jelentés. *(Az új mutatók: felmérés-foglalások, megrendelések, modulok állapota — átírandó.)*

## 6. A fejlesztői ág ügynökei (ELŐTÉRBEN, D23, D29)

**Az irányadó leírás: `10-fejlesztoi-ag-alugynokok.md`.** Röviden:

| Ügynök | Osztály | Fő feladat |
|---|---|---|
| Hibakeresés | olvasó | Diagnózis és javaslat, nem módosít. |
| Modulépítés | író | Az egyedi modulok építése, az adat/séma-feladatokkal együtt. |
| Tudásrendszerezés | meta | Általánosítható tudás és skill-javaslat, ügyféladat nélkül. |
| Webfejlesztő | író | twinx.hu oldalai, irodai fiók felülete, ügyfélnek épített app/oldal. |
| Modul tesztelő | olvasó | Átadás előtti ellenőrzés, `kifogas`-szal megállíthat. |
| Felmérő | olvasó | Piackutatás és cégfelmérés (előkészítés + összegzés), ügyfél-adat csak `privat` hatókörben. |

A regiszterben `branch = 'fejleszto'`, `active = true` az előtérbe kerüléskor (Márk kapcsolja be).

## 7. Regiszter (a `agents` tábla bővítése)

Az ügynökökhöz új mezők kellenek:
- `branch`: `partner` / `fejleszto`
- `permission_class`: `olvaso` / `iro` / `kifele` / `meta`
- `uses_llm`: van-e LLM-hívása
- `model`: melyik modell (configból, cserélhető)
- `active`

Új ügynököt ugyanígy, a háromrészes sablonnal (alapokmány, képességek, memória-hatókör) lehet felvenni. MAX kódjához ehhez nem kell nyúlni.
