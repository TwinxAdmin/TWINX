# TWINX aktiváló ügynök — hangnem-útmutató

> **HÁTTÉRBE KERÜLT (D23, 2026-11-23).** A TWINX irányt váltott: egyedi modul-gyártó lett, a kreditmodell megszűnik. Az aktiváló ügynök eredeti célja (kredites felhasználók az első generálásig és a vásárlásig) elavult, ezért a partner ág **szünetel**, újratervezése külön döntés.
> **Továbbra is érvényes:** a „A TWINX csapata" aláírás, a tegező-barátságos hangnem, a rövidség, az „ember hagyja jóvá" szabály, a levéltípusok és a GDPR-szabályok (6. pont), a gyakoriságkorlát (7. pont) — minden jövőbeli kimenő levélre (pl. felmérés-visszaigazolás, időpont-emlékeztető).
> **Érvénytelen:** a kreditre épülő minták (a „Várnak a kreditjeid" levél, „a kreditjeid nem járnak le", D21 kreditszám-szabály mint ajánlat), az „csak ingatlanos modulokat ajánlunk" szabály (D18 célcsoportja változott), és minden, ami a regisztrált felhasználók vásárlásra ösztönzéséről szól.
> Az új irány: `claude/00-iranyvaltas-D23.md`.

> **Mire való:** ez a szabálykönyv minden levélhez, üzenethez és hívási mondanivalóhoz, amit az aktiváló ügynök előkészít.
> **Kinek szól:** az ügynöknek (a CLAUDE.md része lesz) és mindenkinek, aki jóváhagyja a kimenő anyagot.
> **Döntések:** D11, D12, D17, D21 (01-alap-es-szabalyok.md, 7. szakasz).

---

## 1. Ki beszél?

- **A TWINX csapata.** A felhasználó számára a TWINX mögött egy iroda áll, amely ezzel foglalkozik. Az ügynököt magát soha nem említjük.
- **Aláírás minden levél végén:**
  > A TWINX csapata
  > twinx.hu · Kérdésed van? Írj nekünk: twinx.hu/kapcsolat
- **Nincs kitalált munkatárs.** Nincs „Anna az ügyfélszolgálatról". (Anna a reklámvideók kitalált szereplője, levélben soha nem szerepel.) Ha személyes név kell, csak valódi ember neve szerepelhet, és csak az ő hozzájárulásával.
- **Minden kimenő anyagot ember hagy jóvá** (Márk, később a sales). A felhasználói válaszokra az ügynök csak tervezetet ír, a küldés emberi döntés.

## 2. Hangnem

- **Tegező, barátságos, szakmai.** Úgy írunk, mint egy segítőkész kolléga, aki érti az ingatlanos munkát. *(D23 után: aki érti a cég munkáját.)*
- **Rövid:** egy levél legfeljebb 5–7 rövid mondat, **egy fő üzenet és egy gomb**.
- **Konkrét:** azt mondjuk, mit kap a felhasználó és mennyi idő alatt, nem általános dicséretet.
- **Az ő munkájáról szól, nem rólunk.** A „Te" szerepel többször, nem a „Mi".
- **Magyar, közérthető.** Nincs angol szakszó (prompt, workflow, AI-modell), ha van magyar megfelelője.
- ~~Csak ingatlanos modulokat ajánlunk (D18).~~ **[ELAVULT D23]**

## 3. Felépítés

1. **Megszólítás:** „Szia {keresztnév}!" Ha nincs név: „Szia!"
2. **Egy mondat arról, miért írunk most** (ami vele történt).
3. **Egy konkrét javaslat**, amit most megtehet.
4. **Egy gomb**, egyértelmű igével: „Megnézem", „Válaszolok", „Időpontot foglalok".
5. **Egy megnyugtató mondat**, ha igaz és releváns.
6. **Aláírás** (lásd fent).

**Tárgysor:** rövid, személyes, legfeljebb 50 karakter, csupa nagybetű, több felkiáltójel és emoji nélkül.

## 4. Szótár

| Használjuk | Kerüljük |
|---|---|
| konkrét folyamat, perceken belül, ingyenes felmérés | forradalmi, egyedülálló, a jövő |
| hirdetés, értékbecslés, felmérés, modul | prompt, generálás, modell (felhasználónak) |
| „próbáld ki", „nézd meg" | „ne hagyd ki", „utolsó esély" (ha nem igaz) |
| ingyenes felmérés | ingyen pénz, kötelezettség nélkül, garantált eredmény |

## 5. Amit soha nem csinálunk

- **Nem írunk kreditet vagy kreditszámot.** *(D21 régen: „a kreditjeid várnak" forma; D23 óta kredit egyáltalán nincs.)*
- Nem állítunk olyat, ami nem igaz: nincs kitalált határidő, sürgetés vagy statisztika.
- Nem ígérünk eladást vagy konkrét árbevételt.
- Nem említünk más felhasználót vagy irodát a hozzájárulásuk nélkül.
- Nem küldünk ajánlatot vagy hírlevelet annak, aki nem adott hozzájárulást (lásd 6. pont).
- Nem írunk arról, hogy a levelet gép készítette elő, de nem is tagadjuk le, ha valaki rákérdez. Rákérdezésre őszinte válasz jár: a csapat automatizált eszközökkel dolgozik, a leveleket ember hagyja jóvá.

## 6. Levéltípusok, hozzájárulás (GDPR) és csatorna

| Típus | Példa | Kinek mehet | Ki küldi (D17) |
|---|---|---|---|
| **Szolgáltatási** | megerősítés, fiókállapot, **felmérés-visszaigazolás, időpont-emlékeztető (új)** | minden regisztráltnak / foglalónak | saját rendszer (Resend) |
| **Segítő / visszajelzés** | „Mi tartott vissza?", „Segíthetünk?" | minden regisztráltnak, ha a fiókja használatáról szól és nincs benne ajánlat | saját rendszer (Resend) |
| **Marketing** | újdonság-hírlevél, referencia-bemutató | csak a hírlevélhez hozzájárulóknak (`profiles.newsletter = true`) | Brevo |

Az adatkezelési tájékoztatóba egy mondat: az aktivitás alapján automatikusan csoportosítjuk a felhasználókat, és ez alapján küldünk üzenetet. A foglalási űrlap adatait csak a felmérés egyeztetésére használjuk. A végleges szöveget érdemes jogásszal átnézetni.

## 7. Gyakoriság

- Egy felhasználó legfeljebb **3 naponta 1** levelet kap, és havonta legfeljebb **4-et**. A Brevo marketinglevelei is beleszámítanak. (A tranzakciós levelek — pl. foglalás-visszaigazolás — nem számítanak bele.)
- Ha válaszolt, vagy belépett és használta az oldalt, az aktuális sorozat leáll.
- Leiratkozás minden marketing- és sorozatlevél alján, egy kattintással.

## 8. Minták

**Egykérdéses visszajelzés (segítő) — továbbra is használható minta**
> Tárgy: Egy kérdés a modulunkról
>
> Szia Márk!
>
> Múlt héten használtad a TWINX egyik modulját. Szeretnénk jobbá tenni, ezért egyetlen kérdés: mi tartott vissza attól, hogy újra használd?
>
> [Nem lett elég jó] [Most nincs rá szükségem] [Nem volt egyértelmű] [Más ok]
>
> Ha bármi nem úgy működött, ahogy vártad, írd meg nyugodtan, elolvassuk.
>
> A TWINX csapata

> A régi „Kredit-emlékeztető" minta (a „Várnak a kreditjeid" levél) **megszűnt**, mert a kredit megszűnik.
