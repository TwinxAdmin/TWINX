# TWINX aktiváló ügynök — első kör (specifikáció)

> **HÁTTÉRBE KERÜLT, SZÜNETEL (D23, 2026-11-23).** A TWINX egyedi modul-gyártóvá vált, a kreditmodell megszűnik. Ez a specifikáció a **kredites** felhasználók aktiválására készült (első generálás → második használat → vásárlás), ezért a célja és a mérőszámai elavultak. **Ne építsd meg így.**
> **Mi használható később:** a napi állapot-besorolás mint ötlet, a Telegramos reggeli jóváhagyás (4. pont), a visszajelzés-gyűjtés (6. pont), a heti jelentés szerkezete (7. pont) és a gyakorisági korlát.
> **Mi érvénytelen:** a „Fogyó kredit", „Vásárló" állapot, a kredit-emlékeztető és a „Készítsük el neked" meghívó levelek, a vásárlásra épülő mérőszámok.
> **Újratervezés:** külön döntés, `01-alap-es-szabalyok.md` 8. szakasz (nyitott döntések). Az új irány: `claude/00-iranyvaltas-D23.md`.

> **Cél (eredeti):** a regisztrált felhasználók jussanak el az első generálásig, a második használatig, végül a vásárlásig.
> **Döntések:** D11–D21 (01-alap-es-szabalyok.md). **Hangnem:** 06. **Gyártó ág:** 07. **Ügynökök:** 09.
> **Állapot:** terv, jóváhagyva 2026-11-05; 2026-11-23-tól szünetel.

---

## 1. Állapotok (napi besorolás)

A **Besoroló** ügynök naponta egyszer (reggel, a jóváhagyás előtt) minden `role = 'user'` felhasználót besorol a TWINX Supabase adatai alapján (`auth.users`, `profiles`, `usage_history`, `wallets`, `credit_purchases`). A termék-adatbázisból csak olvas, egy csak olvasható szerepkörrel. A saját állapotát a `twinx-agents` adatbázisban tárolja (`user_states`).

| Állapot | Feltétel |
|---|---|
| **Nem erősített** | `email_confirmed_at` üres |
| **Nem kezdte el** | megerősített, 0 használat |
| **Egyszer próbálta** | 1–2 használat, az utolsó óta legalább 3 nap telt el |
| **Visszatérő** | 3+ használat |
| **Fogyó kredit** | egyenleg < 2 kredit és volt már használat *(elavult, D23)* |
| **Vásárló** | van jóváírt vásárlás *(elavult, D23)* |
| **Alvó** | 30 napja nincs belépés és használat |

**Elsőbbségi sorrend, ha több állapot is illik:** Vásárló > Fogyó kredit > Visszatérő > Egyszer próbálta > Nem kezdte el > Nem erősített. Az **Alvó** mindegyiket felülírja.

Állapotváltáskor a régi sorozat azonnal leáll, és az új állapot sorozata indul.

## 2. Sorozatok (hívás nélkül — D14: egyelőre csak levelek mennek)

| Állapot | Időzítés | Levél | Típus (06, 6. pont) |
|---|---|---|---|
| Nem erősített | +1 nap | megerősítő levél újraküldése (a meglévő `auth.resend` logikával) | szolgáltatási — **továbbra is hasznos** |
| | +4 nap | még egyszer, utána leáll | szolgáltatási |
| Nem kezdte el | +0 nap | üdvözlő levél *(új irányhoz át kell írni: nincs kredit)* | szolgáltatási |
| | +2 nap | „Készítsük el neked" meghívó *(szünetel, D23)* | segítő |
| | +6 nap | kredit-emlékeztető *(megszűnt, D23)* | – |
| | +12 nap | „Segíthetünk?" — rövid kérdés | segítő |
| Egyszer próbálta | +3 nap | következő lépés ajánlása a használat alapján *(átírandó)* | segítő |
| | +7 nap | egykérdéses visszajelzés: „Mi tartott vissza?" | segítő |
| | +14 nap | „Készítsük el neked" meghívó *(szünetel, D23)* | segítő |
| Fogyó kredit | – | *(megszűnt, D23)* | – |
| Alvó | 30 nap | „Mi újság nálunk" — 2–3 újdonság röviden | **marketing — Brevo, csak hozzájárulással** |
| Visszatérő, Vásárló | – | első körben nincs sorozat | – |

**Gyakorisági korlát** (minden csatornára együtt, a Brevo marketingleveleit is beleszámolva): legfeljebb 3 naponta 1 levél, havonta legfeljebb 4. Ha egy levél a korlát miatt nem mehet ki, a következő szabad napra csúszik. A **Sorozatszervező** tartja be, és kifogást emel, ha egy levél sértené.

## 3. Küldés: saját sorozat a Resenddel, a Brevo csak marketing (D17)

- **Szolgáltatási és segítő levelek:** az ügynökség **saját rendszere küldi a Resenddel** (a **Kézbesítő** ügynök), a hitelesített twinx.hu domainről, „A TWINX csapata" aláírással.
- **A Brevo csak marketingleveleket küld** (újdonság, hírlevél), és csak a hírlevélhez hozzájárulóknak.
  - Hogy a gyakorisági korlát közös legyen, az ügynök minden reggel lekéri a Brevóból, kinek ment ki marketinglevél az elmúlt napokban (Brevo API: kontakt e-mail-események).
- **Leiratkozás:** minden levél alján. Az ügynök levelei és a Brevo leiratkozási listája szinkronban van: aki az egyikből leiratkozik, a másikból is.
- **Előfeltétel:** a twinx.hu domain hitelesítése a Resendben (DNS-rekordok a Rackforestnél). Enélkül a levelek nagy része nem érkezik meg.

## 4. Napi jóváhagyás Telegramon (D14)

Minden reggel (pl. 8:30, Europe/Budapest) egy üzenet:
> *Mai javaslat: 5 levél — … [Mutasd] [Mehet mind] [Ma ne]*

- **Mehet mind:** minden levél kimegy, napközben elosztva (nem egyszerre).
- **Mutasd:** egyenként végiglapozható (címzett keresztneve, állapot, tárgy, szöveg), mindegyiknél [Mehet] [Kihagy].
- **Ma ne:** semmi nem megy ki, a levelek másnapra csúsznak.
- Ha 12:00-ig nincs válasz, aznap nem megy ki semmi (biztonsági alapállás).

## 5. Felzárkóztatás: a meglévő felhasználók (D14)

- A mostani regisztráltak (2026-11-05-én: 21 landinges + 12 egyéb) is bekerültek volna.
- **Szünetel, D23.** Újraindítás előtt át kell gondolni, milyen üzenetet kapnak a meglévő regisztráltak az új irányról (pl. a TWINX új irányát bemutató levél).

## 6. Visszajelzések (D14)

- A válaszok (egykérdéses visszajelzés, „Segíthetünk?" válaszai) három helyre kerülnek, a **Visszajelzés-figyelő** ügynök útján:
  1. **TWINX admin → „Visszajelzések"** lista: dátum, felhasználó, állapot, kérdés, válasz, szabad szöveg; szűrhető válaszkategóriára.
  2. **Telegram:** azonnali üzenet minden új szöveges válaszról (a választható gombos válaszok csak a napi összesítőben).
  3. **Heti jelentés.**
- Ha a felhasználó a levélre e-mailben válaszol, a Levélíró **választervezetet** ír, és Telegramon küldi el jóváhagyásra. Automatikus válasz nem megy ki (D12).

## 7. Heti jelentés (hétfő reggel, Telegram + admin)

Az **Elemző** ügynök írja:
- Állapotonkénti létszám és a változás az előző héthez képest.
- Kiküldött levelek típusonként, megnyitás és kattintás.
- ~~Hányan generáltak először, hányan másodszor, hányan vásároltak.~~ *(D23: átírandó az új mutatókra, pl. felmérés-foglalások.)*
- Visszajelzések összesítve kategóriánként + a szabad szöveges válaszok.

## 8. Mérőszámok (eredeti, történeti)

| Mutató | Kiinduló érték (2026-11-05, landinges felhasználók) |
|---|---|
| Első generálás a regisztrációtól számított 7 napon belül | kb. 33% |
| Második használat | kb. 0% |
| Első vásárlás 30 napon belül | 0% |
| E-mail-megerősítés | 71% (15 / 21) |

*(Ezek az adatok járultak hozzá az irányváltáshoz, D23.)*

## 9. Kikapcsolt / későbbre hagyott

- **Hívólista és hívás-eredmény rögzítése:** első körben kikapcsolva (D14).
- Visszatérő és vásárló felhasználók sorozatai.
- LLM-mel személyre szabott levélszöveg: első körben sablonok + kitöltött mezők (név, használt modul, helyiség), LLM csak a választervezeteknél és a gyártó ág tippjeinél.
