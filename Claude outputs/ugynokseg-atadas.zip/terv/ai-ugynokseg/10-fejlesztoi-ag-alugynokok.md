# TWINX ügynökség — a fejlesztői ág alügynökei (D29)

> **Döntés:** 2026-11-23, Kovács Márk (D29). **Ez a dokumentum az irányadó az alügynökök listájához;** a `02` (4.3) és a `09` (1., 6. szakasz) régebbi „egyeztetendő" jelölései ennek megfelelően értendők.
> **Kontextus:** a TWINX egyedi modul-gyártó (D23, `claude/00-iranyvaltas-D23.md`). A fejlesztői ág az előtérben van, és a megrendelések kiszolgálását segíti.

---

## 1. A mag: 6 alügynök (indulás)

| # | Ügynök | Korábbi név (02/09) | Osztály | Fő feladat |
|---|---|---|---|---|
| 1 | **Hibakeresés** | Kutató-diagnoszta | olvasó | Elakadások első felelőse: kódot, logot, dokumentációt olvas, külső API-kat ellenőriz, diagnózist és javaslatot ad. Nem módosít. |
| 2 | **Modulépítés** | Modul-építő | író | Az egyedi, cégre szabott modulok (és a meglévők) gyártása, karbantartása. **Az adat/séma-feladatokat (Supabase, migráció, RLS) is ő viszi** — a korábbi külön Adat/Supabase szerep beleolvad. Deploy és prod-írás kapuzott. |
| 3 | **Tudásrendszerezés** | Skill-építő | meta | Ismétlődő problémából és az ügyfélmunkákból általánosítható tudást rendszerez, skill-javaslatot ír. Ügyfél adatát nem viszi a közös tudásba. Új skill csak kapun át. |
| 4 | **Webfejlesztő** | Web/frontend | író | A twinx.hu oldalai (főoldal, landing, felső sáv, időpontfoglaló), az irodai fiók felülete, és az ügyfélnek épített saját app vagy oldal. Csak feature-ágon ír; main-push és deploy kapuzott. |
| 5 | **Modul tesztelő** *(új)* | – (a partner ág Minőségellenőréből általánosítva) | olvasó | Átadás előtt ellenőrzi a modult: teszt-terv, tesztadat, ismétlő ellenőrzés, hibalista. `kifogas` üzenettel megállíthatja az átadást. Nem javít, hanem jelez. |
| 6 | **Felmérő** *(új)* | – | olvasó | **Egy ügynök, két üzemmód:** (a) **előkészítés** — a foglalás és a cég nyilvános adatai alapján felkészíti a beszélgetést (piackutatás); (b) **összegzés** — a beszélgetés jegyzetei alapján folyamat-térképet, kérdéslistát és modul-javaslatot ír. |

## 2. A Felmérő részletei (piackutató + cégfelmérő egyben)

- **(a) Előkészítés:** bemenet a foglaláskor megadott pár mondat (nem kötelező) és a **cég nyilvános adatai** (honlap, szolgáltatások, iparág). Kimenet: rövid előkészítő lap Márknak vagy Tibinek — mit érdemes kérdezni, hol lehet tipikusan időt nyerni.
  - **Csak céget kutat, magánszemélyről profilt nem készít.** A nyilvános céges adatot külső inputként, karanténban kezeli.
- **(b) Összegzés:** bemenet a beszélgetés jegyzete (Márk vagy Tibi írja). Kimenet: folyamat-térkép, a legtöbb időt vivő lépések, 1–3 modul-javaslat, nyitott kérdések. **Ez már az ügyfél privát adata:** csak `privat` hatókörű memóriába és az ügyfélhez kötött feladatba kerülhet (D23, `02` 5.2).
- **Nem csinál:** árat nem mond, ajánlatot nem küld, az ügyfélnek nem ír. Az árazás és az ajánlat Márk és Tibi döntése.
- **Jóváhagyás:** nincs kimenő üzenet, tehát kapu nem kell; az eredmény Márkhoz és Tibihez kerül.

## 3. Egy megrendelés útja (illusztráció)

1. A cég időpontot foglal (D26) → **Felmérő** előkészít.
2. **Márk vagy Tibi** megtartja az ingyenes beszélgetést.
3. **Felmérő** összegez → **Márk és Tibi** dönt, és ők készítik az ajánlatot.
4. Megrendelés esetén: **Modulépítés** + **Webfejlesztő** épít; a **Hibakeresés** segít az elakadásnál.
5. **Modul tesztelő** átadás előtt ellenőriz; az átadást Márk végzi.
6. **Tudásrendszerezés** az általánosítható tanulságot rögzíti, az ügyfél adata nélkül.

## 4. Félretett szerepek (később szükség lehet rájuk)

Ezek **nem épülnek most**; akkor kerülnek elő, ha a feltétel teljesül.

| Szerep | Mit csinálna | Mikor érdemes |
|---|---|---|
| **Ajánlat- és költségbecslő** | A felmérés után javaslat a munkaórára, az API-költségre és a havi díjra; Márk dönt. | Az **első bővítés**, amint megvan az árképzési szabály (fejlesztési díj + havi előfizetés). |
| **Dokumentáló / átadó** | Ügyfél-kézikönyv, oktatóanyag, változásnapló a kész modulhoz. | Ha az átadás dokumentálása sok kézi időt visz el. |
| **Üzemeltető-figyelő** | Az élesben futó ügyfél-modulok figyelése, hibajelzés. | Amikor több ügyfél-modul fut havi előfizetéssel. |
| **Ügyfélkapcsolattartó** | A **megrendelő új cégekkel** tartja a kapcsolatot: foglalás-visszaigazolás, időpont-emlékeztető, állapotfrissítés az építés alatt, átadás utáni visszajelzés. **Kifelé kommunikáló, mindig kapuzott** (D12), az ügyfél adata csak az ő hatókörében. | Ha a kézi levelezés sok időt visz el. |
| **Marketinges** | A TWINX saját népszerűsítése (D10). | **Most Márk és Tibi csinálja kézzel**; később külön ágként. |
| **Piackutató (külön)** | Önálló piac- és iparágfigyelés. | Ha a Felmérő előkészítő üzemmódja kinőné magát; most a Felmérőben van. |
| **Adatvédelmi őr** | — | **Nem ügynök, hanem szabály és kód:** az ügyfélanyag csak az ügyfél hatókörébe kerülhet, a közös tudásba nem (`02` 5.2). |

## 5. Regiszter-bejegyzések (a Code-nak)

A 6 mag-ügynök: `branch = 'fejleszto'`, `active = true` az előtérbe kerüléskor (Márk kapcsolja be). A `permission_class`: hibakeresés `olvaso`, modulépítés `iro`, tudásrendszerezés `meta`, webfejlesztő `iro`, modul tesztelő `olvaso`, felmérő `olvaso`. Az alapokmány, a képességek és a memória-hatókör külön, ügynökönként készül (a háromrészes sablon szerint, `02` 4.2).

## 6. Nyitott pontok

- `[DÖNTÉSRE VÁR]` A Modul tesztelő hogyan fér hozzá a teszt-környezethez (külön Supabase-ág vagy fejlesztői adatbázis), és mit futtathat.
- `[DÖNTÉSRE VÁR]` A beszélgetés jegyzetét ki és hol rögzíti a Felmérőnek (Telegram, doc, űrlap).
- `[KITÖLTENDŐ]` Az alapokmányok (ügynökönként) — következő ötletelési kör.
