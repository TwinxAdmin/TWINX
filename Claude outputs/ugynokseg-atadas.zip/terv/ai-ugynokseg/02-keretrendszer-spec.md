# TWINX ügynök-keretrendszer — specifikáció

> **FRISSÍTVE (D23, D29, 2026-11-23): a fejlesztői ág kerül előtérbe.** A TWINX egyedi modul-gyártóvá vált (`claude/00-iranyvaltas-D23.md`). A keretrendszer váza (főügynök, feladat-tábla, memória, kapuk) változatlan és érvényes. Ami változik: a **fejlesztői ág** (4.3) az első, amit élesítünk, az egyedi modul-építés segítésére, **6 alügynökkel** (D29, részletek: `10-fejlesztoi-ag-alugynokok.md`); a **partner ág** építési sorrendje (11. szakasz) **szünetel**.

> **Mi ez:** a saját, otthoni gépen futó, több-ügynökös fejlesztő-keretrendszer terve.
> **Mi NEM ez:** a TWINX termék tudásbázisa — az a `CLAUDE.md`. Ez a dokumentum a rendszer *felépítéséről* szól
> (hogyan van összerakva), a `CLAUDE.md` pedig arról, *mit kell tudni a TWINX-ről*. A kettő együtt jár.
>
> **Kinek szól:** neked (aki Claude-dal, lépésről lépésre építed), és később a freelance fejlesztőnek.
> **Nyelv:** magyar. **Jelölés:** `[KITÖLTENDŐ]` / `[DÖNTÉSRE VÁR]` a még nyitott részek.

---

## 1. Áttekintés

- **Cél:** egy több-ügynökös rendszer, ami feladatokat fogad tőled, szétosztja specializált ügynököknek, felügyeli őket, és jóváhagyásra eléd teszi az eredményt.
- **Két ág MAX alatt (D16, D23):** a **fejlesztői ág** az egyedi modulok építését segíti (felmérés, modulépítés, tesztelés, hibakeresés, tudásrendszerezés, webfejlesztés) — **ez az előtérben van**. A **partner ág** a meglévő felhasználókkal foglalkozott (D11), **háttérben, szünetel**. Az ügynökök pontos leírása: `09-ugynokok-spec.md`, `10-fejlesztoi-ag-alugynokok.md`.
- **Hol fut:** a te otthoni gépeden. Egy **launch agent** (macOS `launchd`) indítja, és újraindítja, valahányszor a gép életre kel.
- **Mi indítja el a munkát — két trigger:**
  - **Óránkénti pulzus** — a rendszer magától felébred, és megnézi, van-e tennivaló (autonóm háttérmunka).
  - **Telegram-üzenet** — amikor te adsz feladatot, az *azonnal* elindítja a kört, nem vár a következő órára.
- **Emberi felület:** Telegram (elsőre csak neked; később egy-egy ügynök megosztható lesz, pl. Tibivel).
- **Memória:** Supabase (Postgres), ahol kell, vektorizált kereséssel.
- **Fontos korlát:** csak akkor fut, amikor a géped be van kapcsolva. A gép naponta legalább egyszer fut, hétvégén is (D15). Bekapcsoláskor az első pulzus pótolja a napi feladatokat. Védelem: bekapcsolt állapotban alvás tiltva, és egy külső életjel-figyelő szól, ha a pulzus kimarad. (A weboldalba épülő ügyfél-ügynök később külön, felhős telepítés lesz — lásd 9.)

## 2. Alapelvek (a rendszer öt aranyszabálya)

1. **A főügynök vékony — irányít, nem dolgozik.** Eldönti, ki mit csináljon, de a munkát az al-ügynökök végzik, és nem folyik át rajta minden üzenet.
2. **Állapotmentes pulzus.** Két futás között semmi nem él "a fejben" — minden állapot a Supabase-ben van. Minden futás: *olvasd az állapotot → cselekedj → írd vissza → állj le.* Így egy kikapcsolt éjszaka vagy hét után is pontosan onnan folytatódik, ahol abbamaradt.
3. **Javasol → te jóváhagyod.** Minden kockázatos vagy visszafordíthatatlan lépés (deploy, prod-írás, a TWINX-repó módosítása, új skill, a keretrendszer önmódosítása) csak a te jóváhagyásoddal megy élesbe.
4. **Ami kívülről jön, az karanténba kerül.** Külső input (webhook, netről behúzott skill, **ügyfél által átadott anyag**, a cégek nyilvános oldala) sosem kap automatikusan bizalmat vagy jogosultságot.
5. **Naptár-alapú ütemezés.** A "napi" és "heti" folyamatok naptári nap/hét szerint futnak (az első pulzus, ami új napot/hetet lát), nem futásidő-órák szerint — így kikapcsolt gép mellett sem maradnak ki.

---

## 3. A főügynök

### 3.1 Hat felelősség
1. **Felvétel (intake):** veled beszél Telegramon, értelmezi a feladatot, kétértelműségnél visszakérdez. **Új (D23):** a felmérésből jövő megrendelést is feladatként veszi fel.
2. **Feladatbontás és útválasztás:** részfeladatokra bont, eldönti, melyik al-ügynök vigye, milyen sorrendben/függőséggel.
3. **Kiosztás és koordináció:** a részfeladatokat a feladat-táblába írja; az al-ügynökök onnan veszik.
4. **Felügyelet:** figyeli a haladást, elkapja a beragadt/hibázó ügynököt.
5. **Jóváhagyási kapu:** a kapuzott lépéseket összefoglalja neked, és megvárja a döntésed.
6. **Visszajelzés:** a pulzus végén összefoglal Telegramon.

### 3.2 A pulzus-hurok (mi történik egy futáskor)
Minden futás (akár óránkénti pulzus, akár Telegram-esemény indítja) ezt a sort járja be:

1. **Új naptári nap?** → zárd le az előzőt (napló + memória-konszolidáció), állítsd fel a napi **top 3 célt**.
2. **Új naptári hét?** → futtasd a heti konszolidációt és a külső skill-felderítést (mind javaslatként).
3. **Olvasd be az állapotot** a feladat-táblából.
4. **Intake:** új Telegram-üzenet → új feladat(ok) `nyitott` állapotban.
5. **Útválasztás:** a `nyitott`, függőség-mentes feladatokhoz rendelj al-ügynököt (`kiosztva`).
6. **Futtatás:** a kiosztott ügynökök lefuttatják a körüket, és az eredményt/javaslatot visszaírják a táblába.
7. **Elakadás-kezelés:** a túl régóta `fut`/`kiosztva` vagy `elakadt` feladatoknál dönts — újrapróbál / átirányít / hozzád eszkalál / (ismétlődő probléma → skill-jelölt).
8. **Kapu:** a `kapura_vár` feladatokat tedd elém Telegramon; a jóváhagyottak hatását alkalmazd (`kész`), az elutasítottakat irányítsd vissza.
9. **Írd vissza az állapotot, foglalj össze, állj le.**

### 3.3 Karbantartó / "dreaming" mód
A fejlesztő-munka mellett a főügynök gondozza is a rendszert — külön, ritkább ütemben, **mindig csak javaslati jogkörrel**:

- **Napi (a nap lezárásakor):**
  - **Napló** — összefoglaló az aznap elvégzett feladatokról (neked). Ez egyben az a pont, ahol a **hot memória hűl warm/cold felé**.
  - **Utólagos visszafésülés** — volt-e a napban skill-jelölt, ami kimaradt, vagy fontos elem, ami nem került a naplóba → **jelzi neked**.
- **Napi (a nap első pulzusakor):**
  - **Top 3 cél** — a nyitott feladatokból, a tegnapi naplóból és az általad adott prioritásokból levezetve, Telegramon eléd téve (felülbírálhatod).
- **Heti (naptári hét első pulzusa):**
  - **Memória-konszolidáció** — duplikátumok, elavult elemek, hot→warm→cold mozgatás (javaslatként).
  - **Skill-konszolidáció** — átfedő/elavult/sosem használt skillek összevonása vagy archiválása (javaslatként).
  - **Külső skill-felderítés** — körülnéz a neten, mi lehet érdemes beépíteni; **összefoglal és linkel**, de a netről jött dolog karanténba kerül (5. alapelv), és csak a te kapud mögött válik saját, ellenőrzött skillé.

### 3.4 A főügynök "esze" vs. "körítése"
A pulzus-hurok nagy része **sima kód** (olvasás, állapotírás, ütemezés, kapuk). **LLM-hívás csak a valódi döntési pontokon** van: a feladatod értelmezése, a feladatbontás, az útválasztás, a napló/top 3 megfogalmazása. Ez tartja olcsón és kiszámíthatóan a rendszert.

---

## 4. Al-ügynökök

### 4.1 Jogosultsági osztályok
- **Olvasó** — nem ír sehova, csak vizsgál és javasol. Kapu nélkül, felügyelet nélkül is futhat.
- **Író** — dolgozhat dev-környezetben/ágon, de a kockázatos akció (deploy, prod-írás, main-merge) kapuzott.
- **Meta / privilegizált** — a rendszert vagy a saját tudását módosítja; mindig kapuzott, legmagasabb kockázat.

### 4.2 A három-mezős sablon (minden ügynök így van definiálva)
- **Alapokmány** — a szerepe + a te elvárásaid róla. Stabil, általad írt, verziózott. (NEM a hőmérséklet-tierekben él.)
- **Képességkészlet** — milyen eszközöket hívhat (pontosan annyit, amennyi a dolgához kell — se többet).
- **Memória-hatókör** — mit olvas/ír a tier + scope modellből.

Ez egyben a bővítés sablonja is: új ügynököt ezzel a három mezővel veszel fel, és a **regiszterbe** bekerülve válik útválaszthatóvá — a főügynök kódját nem kell bántani.

> **Frissítés (2026-11-05):** a jogosultsági osztályok közé bekerült a **kifelé kommunikáló** osztály (valódi embernek küld üzenetet, mindig kapuzott). A partner ág kilenc ügynöke és a bővített osztályok leírása a `09-ugynokok-spec.md`-ben van.

### 4.3 A fejlesztői ág szerepei (D23, D29: ELŐTÉRBEN, 6 alügynök)

> **Döntés (2026-11-23, D29):** az indulási mag **6 alügynök**: hibakeresés, modulépítés, tudásrendszerezés (a mostani három) + webfejlesztő, modul tesztelő, felmérő. A korábbi külön Adat/Supabase szerep a modulépítésbe olvad. A félretett szerepek (ajánlat- és költségbecslő, dokumentáló, üzemeltető-figyelő, ügyfélkapcsolattartó, külön piackutató) és a részletek: `10-fejlesztoi-ag-alugynokok.md`.

| Ügynök | Osztály | Pontos feladat |
|---|---|---|
| **Hibakeresés** (Kutató-diagnoszta) | olvasó | Elakadások első felelőse: kódot, logot, dokumentációt olvas, ellenőrzi a külső API-kat, diagnózist + javaslatot ad. Nem módosít. Ő táplálja a főügynök "ismétlődő-e a probléma?" döntését. |
| **Modulépítés** (Modul-építő) | író | A termék-modulok (`src/app/api/**`, `src/lib/**`, SQL) gyártása/karbantartása — **az egyedi, cégre szabott modulok építése is**. **Az adat/séma-feladatok (Supabase, migráció, RLS, a modul-jogosultság adatmodellje, D25) is hozzá tartoznak.** Dev-en szabadon; deploy, prod-migráció/-írás kapuzott, visszafordítható migrációkkal. |
| **Tudásrendszerezés** (Skill-építő) | meta | Ismétlődő elakadásnál megírja a skill *javaslatát* strukturált `SKILL.md`-formában, indoklással. Az ügyfélmunkákból általánosítható tudást is rendszerezi — az ügyfél adata nélkül. A könyvtárba csak a te kapud után kerül. |
| **Webfejlesztő** (Web/frontend) | író | Next.js oldalak (`src/app/(public\|dashboard\|auth)/**`) és `src/components/**`: főoldal, landing, új felső sáv, időpontfoglaló, irodai fiók felülete, és az ügyfélnek épített app vagy oldal. Csak feature-ágon ír; main-push és Vercel-deploy kapuzott. |
| **Modul tesztelő** *(új)* | olvasó | Átadás előtt ellenőrzi a modult (teszt-terv, tesztadat, hibalista); `kifogas` üzenettel megállíthatja az átadást. Nem javít, jelez. |
| **Felmérő** *(új)* | olvasó | Egy ügynök, két üzemmód: **előkészítés** (a cég nyilvános adatai alapján, piackutatás) és **összegzés** (a beszélgetés jegyzetéből folyamat-térkép, modul-javaslat). Ügyfél-adat csak `privat` hatókörben. Nem ír ügyfélnek, nem mond árat. |

**Indulási mag (D29):** mind a 6. A fázisolás (10. szakasz) szerint előbb a hibakeresés és a modulépítés, majd a többi.

> A **marketing/sales** ügynökök ide most NEM tartoznak — a marketinget egyelőre Márk és Tibi csinálja kézzel (D29). Ha később ide hozod őket, ugyanezzel a három-mezős sablonnal regisztrálnak be.

### 4.4 Együttműködés (hogyan dolgozik együtt kettő, konfliktus nélkül)
- **Nincs közvetlen ügynök-hívás, de van beszélgetés (D19).** Egy feladaton belül az ügynökök a feladathoz tartozó **szálban** (`task_messages`) egyeztetnek: kérdeznek, válaszolnak, javasolnak, kifogást emelnek. Ha egy munkát egy másik ügynöknek kell elvégeznie, a főügynök **függő részfeladatot** hoz létre. A szálban semmi nem cselekszik, legfeljebb 6 ügynöki üzenet mehet döntés nélkül, utána MAX dönt. Részletek: `09-ugynokok-spec.md`, 3. pont.
- **Egy erőforráshoz egyszerre egy író.** A főügynök úgy oszt, hogy ugyanahhoz a fájlhoz/táblához ne nyúljon két ügynök egyszerre; a párhuzam a *független* munkákra megy.
- **A megosztott tudás a közös memórián át terjed**, nem személyes átadással — így auditálható marad.

---

## 5. Memória-modell

### 5.1 Három tier — ügynökönként
- **Hot** — friss elemek. **Frisseség** alapján kérdezed le (az utolsó N esemény), nem hasonlóság alapján → itt a vektor felesleges.
- **Warm** — a működéshez fontos, a tapasztalatból összesűrített tudás, amit gyakran előhúz.
- **Cold** — archív; jó, hogy megvan és előkereshető (korábbi munkák). Itt éri meg igazán a **szemantikus (vektoros) keresés**.

> **Az alapokmány NEM tier.** A szerep + a te elvárásaid stabil, általad szerkesztett, verziózott konfiguráció — külön tárolva, nem "hűl" és nem archiválódik.

### 5.2 Közös (share) memória + scope
- Van egy **közös memória**, amiről minden ügynök tud (belső TWINX-tudás, közös felismerések).
- **Minden memória-soron van egy `scope` (láthatóság) és egy `owner_id`** — a kezdetektől. Ez teszi később biztonságossá a megosztást: amikor egy ügynököt megosztasz valakivel, csak a **megosztható** hatókörű memóriája + az alapokmánya utazik vele, a privát hot/cold és a belső közös tudás nem.
- `scope` értékek (javaslat): `privat` / `belso_kozos` / `megoszthato`.
- **Új (D23, ügyféladat):** egy ügyfél cégének adata (felmérési jegyzet, folyamatleírás) **csak `privat` hatókörű**, az ügyfélhez kötött `owner_id`-val; a közös tudásba csak anonimizált, általánosítható tanulság kerülhet, kapun át. (Az NDA szabályai véglegesítésre várnak.)
- Ez egyben a Supabase **RLS**-sel (soronkénti hozzáférés-szabályozás) is szépen összeáll, ha később több felhasználó lesz.

### 5.3 Vektorizálás — szelektíven
- Az embedding csak **index** a nyers szöveg fölött — **nem helyettesíti** a szöveget; a nyers szöveget mindig tárold mellé.
- Vektort a **cold** archívumra és a warm kereshető részére tegyél; a hot recency-alapú, oda nem kell.

### 5.4 Memória-tábla — vázlatos oszlopok
`id` · `agent_id` · `tier` (hot/warm/cold) · `scope` (privat/belso_kozos/megoszthato) · `owner_id` · `content` (nyers szöveg) · `embedding` (nullázható, csak ahol kell) · `created_at` · `[KITÖLTENDŐ — pl. tagek, forrás-feladat id]`

---

## 6. A feladat-tábla (a rendszer gerince)

Ez köti össze az egészet: ide oszt a főügynök, erről olvasnak az al-ügynökök, és ezen látszik az elakadás.

### 6.1 Egy feladat sora — oszlopok
| Oszlop | Mit tárol |
|---|---|
| `id` | egyedi azonosító |
| `created_at` / `updated_at` | létrehozás / utolsó módosítás ideje |
| `created_by` | ki hozta létre (főügynök, vagy szülő-feladat) |
| `parent_task_id` | ha egy nagyobb feladat részfeladata |
| `depends_on` | mely feladat(ok)nak kell előbb elkészülnie (id-lista) |
| `title` / `description` | maga a feladat |
| `assigned_agent` | melyik al-ügynök viszi (üres, amíg nincs útválasztva) |
| `status` | az állapot (lásd 6.2) |
| `priority` | fontosság (a top 3-hoz és a sorrendhez) |
| `result` | az eredmény / javaslat-csomag (diff, migráció, skill…) |
| `gate_required` | kell-e jóváhagyás, mielőtt a hatása élesbe megy (igen/nem) |
| `gate_decision` | üres / jóváhagyva / elutasítva |
| `attempts` | hányadik próbálkozás (újrapróbáláshoz) |
| `stuck_reason` | ha elakadt: miért |
| `not_before` | ne induljon el egy adott idő előtt (ütemezéshez) |
| `client_id` *(új javaslat, D23)* | melyik ügyfél megrendeléséhez tartozik (az ügyféladat elkülönítéséhez) |

### 6.2 Állapotgép (egy feladat útja)
```
nyitott ──► kiosztva ──► fut ──┬──► kész
   ▲            │          │    │
   │            │          │    ├──► kapura_vár ──► (jóváhagyva) ──► kész
   │            │          │    │                └─► (elutasítva) ─► kiosztva / lemondva
   │            │          │    │
   └────────────┴──────────┴────┴──► elakadt ──► (főügynök dönt: újra / átirányít / eszkalál / skill-jelölt)
```
- **nyitott** — létrejött, még nincs ügynökhöz rendelve. (Ha van `depends_on`, csak akkor válik útválaszthatóvá, ha azok mind `kész`.)
- **kiosztva** — a főügynök kijelölte az ügynököt, az még nem kezdett bele.
- **fut** — az ügynök dolgozik rajta.
- **kapura_vár** — az ügynök elkészített egy javaslatot, ami jóváhagyást igényel → Telegramon eléd kerül.
- **kész** — befejezve (a hatása, ha kapuzott volt, a jóváhagyás után alkalmazva).
- **elakadt** — az ügynök nem tudott haladni; a főügynök kezeli.
- **lemondva** — érvénytelenítve.

### 6.3 Függőségek (így koordinál két ügynök)
Ha egy feladatnak egy másik ügynök munkája kell (pl. a webfejlesztő oldalához a modulépítő adatmodellje), a főügynök **két feladatot** hoz létre: egy séma-/adat-feladatot a modulépítésnek, és az oldal-feladatot `depends_on = [séma-feladat id]`-vel. Az oldal-feladat `nyitott` marad, amíg a séma-feladat `kész` nem lesz. Így soha nem várnak egymásra "üzenetben", és nincs ütközés.

### 6.4 Elakadás-felismerés (kétféleképp)
- **Kifejezett:** az ügynök maga `elakadt`-ra állítja a feladatot, és kitölti a `stuck_reason`-t (hiányzó infó, döglött API, kétértelmű feladat…).
- **Hallgatólagos:** a főügynök minden pulzusban megnézi, van-e feladat, ami túl rég `fut`/`kiosztva` haladás nélkül (az `updated_at` és az `attempts` alapján) — ez is elakadás.
- **A főügynök döntése elakadásnál:** újrapróbál (növeli az `attempts`-et) / átirányítja másik ügynökhöz / hozzád eszkalál. Ha a probléma **ismétlődő/általánosítható**, akkor skill-jelölt → feladat a tudásrendszerezésnek. Ha **egyszeri**, akkor nincs skill, csak eszkaláció. (Ne szülessen skill minden zökkenőre — attól hígul a könyvtár.)

### 6.5 A kapu a táblában
A jóváhagyás nem külön rendszer, hanem a tábla két mezője: `gate_required` és `gate_decision`. Ha egy feladat kapuzott, `kapura_vár` állapotba kerül, a főügynök Telegramon összefoglalja (mi a javaslat, mi a hatása, miért), és a te válaszod írja be a `gate_decision`-t. Csak `jóváhagyva` után alkalmazza a hatást a rendszer.

---

## 7. Mi kötelezően kapuzott (egy helyen)
- A **TWINX-repót** érintő bármi (main-merge, deploy).
- **Prod DB-migráció/-írás.**
- Új **skill** bekerülése a könyvtárba (kézzel és géppel gyártott is — utóbbi a kapun át).
- A **keretrendszer önmódosítása** (a saját kódja).
- Bármi **visszafordíthatatlan** (törlés) vagy **külső eredetű** (netről behúzott skill, hitelesítetlen webhook).
- **Minden kimenő levél vagy üzenet** egy valódi embernek (felhasználónak, ügyfélnek). *(A korábbi kivételek — értékbecslés kézbesítése, „Készítsük el neked” — a szünetelő partner ághoz tartoztak.)*
- **Új (D23):** minden, ami **ügyféladatot** a közös memóriába vagy az ügyfélen kívülre vinne.

---

## 8. Nyitott kérdések / döntésre vár
- `[DÖNTÉSRE VÁR]` Melyik LLM-modell(ek) hajtsák az ügynököket, és milyen költségkeret mellett (a "költség előre modellezve" elv szerint).
- `[DÖNTÉSRE VÁR]` A regiszter külön tábla legyen, vagy a közös memória egy szelete.
- `[KITÖLTENDŐ]` A pulzuson belül hány ügynök-kör futhat le, mielőtt megáll (guardrail-felső korlát).
- `[KITÖLTENDŐ]` A Telegram-bot pontos parancsai (feladat felvétele, jóváhagyás igen/nem, státusz-lekérdezés).
- `[DÖNTÉSRE VÁR]` A Modul tesztelő teszt-környezete, és a beszélgetés jegyzetének útja a Felmérőhöz (`10`, 6. szakasz).
- `[KITÖLTENDŐ]` Az alügynökök alapokmányai (ügynökönként), és az ügyféladat elkülönítésének pontos szabálya az NDA-val együtt.

---

## 9. Kitekintés — a termékbe kerülő ügynök (NEM most)
Ha egy ügynök beválik, később a **hibrid TWINX-modellben** prémium szolgáltatásként a weboldalra kerülhet. De ez nem ennek a példánynak az átköltöztetése: az **alapokmány + képességek + megosztható memória** *újratelepül* egy külön, felhős, eseményvezérelt, **sandboxolt** környezetbe (nincs repo/deploy-joga, csak az ügyfél feladatához kellő eszközök). A mostani scope-modell (5.2) ezt már előkészíti. Ezt akkor vesszük elő, ha odaérünk.

---

## 10. Javasolt építési sorrend (fázisokban, hogy ne egyszerre kelljen minden)

> Nem vagy profi programozó, ezért a lényeg: **egyszerre egy kicsi, működő darab.** Minden fázis végén legyen valami, ami tényleg fut.

**0. fázis — alapok.** Supabase-projekt, a memória- és a feladat-tábla létrehozása. Telegram-bot regisztrálása (token). A `launchd` beállítása, hogy a rendszer induljon a géppel. *Eredmény:* van hova írni, és a semmi elindul.

**1. fázis — a csupasz hurok.** A pulzus-hurok legszűkebb változata: felébred → beolvassa a táblát → ír egy "élek" sort → összefoglal Telegramon → leáll. Még nincs ügynök. *Eredmény:* látod, hogy pulzál és beszél hozzád.

**2. fázis — intake + egy olvasó ügynök.** Telegramon adsz egy feladatot → `nyitott` sor lesz belőle → a **hibakeresés** (kutató-diagnoszta) felveszi, megnézi, és javaslatot ír a `result`-ba → a főügynök visszaküldi neked. *Eredmény:* egy teljes kör end-to-end, kockázat nélkül (csak olvas).

**3. fázis — az első kapu + egy író ügynök.** A **modulépítés** bekötése, a `gate_required`/`gate_decision` mechanikával. Először minden az ő munkájából kapuzott. *Eredmény:* a rendszer már tud valós változást *javasolni*, de semmi nem megy élesbe a te "igen"-ed nélkül.

**4. fázis — memória-tierek + a napló.** A hot/warm/cold feltöltése, és a napi napló (ami egyben a hot→warm/cold hűtés). *Eredmény:* a rendszer emlékezik és összegez.

**5. fázis — tudásrendszerezés + dreaming.** Ismétlődő elakadás → skill-javaslat, plusz a heti konszolidáció/felderítés. *Eredmény:* a rendszer elkezd "tanulni" — a te kapud mögött.

**6. fázis — a többi mag-ügynök + finomítás (D29).** **Webfejlesztő, modul tesztelő, felmérő**, függőségek, párhuzam, guardrail-korlátok. A félretett szerepek (ajánlat- és költségbecslő stb.) csak az első valódi megrendelések tapasztalata után kerülnek elő. *Eredmény:* a teljes fejlesztői ág.

> **D23 óta ez az ág az előtérben:** a 2–6. fázis a fejlesztői ágra vonatkozik. A fejlesztés a Code-ban, az ügynökség éles indulási kapuja után (üzlettárs egyeztetés + API-költség).

---

## 11. A partner ág építési sorrendje (2026-11-05, D11–D21) — SZÜNETEL (D23)

> **Szünetel.** A kredit megszűnésével a partner ág célja (kredites felhasználók aktiválása) elavult; a lenti sorrend eredeti terv, **ne építsd meg így.** Újratervezése külön döntés (`01`, 8. szakasz). Ami később felhasználható: a besorolás-ötlet, a jóváhagyási kapu, a visszajelzés-gyűjtés.

**P0 — előfeltételek.**
- A Resend domain hitelesítése.
- A laptop alvásának tiltása, és egy külső életjel-figyelő a pulzusra.
- A TWINX adatbázisban egy **csak olvasható** szerepkör az ügynökségnek.

**P1 — Besoroló + Elemző (csak olvas).**
- A regiszter bővítése (`branch`, `permission_class`, `uses_llm`, `model`), a `task_messages` és a `user_states` tábla.
- A napi állapot-besorolás és a heti jelentés Telegramon.

**P2 — Levélsorozatok jóváhagyással.**
- Sorozatszervező, Levélíró, Kézbesítő, az `outgoing_messages` tábla és a gyakorisági korlát.
- A reggeli „Mehet mind” Telegramon, a felzárkóztatás 3 napra elosztva.

**P3 — Gyártó ág.**
- A TWINX-ben: feltöltő oldal, belső gyártási végpont, „A TWINX csapata készítette” jelölés.
- Az ügynökségben: Beérkeztető, Gyártó, Minőségellenőr, a napi keret és a `production_requests` tábla.

**P4 — Visszajelzések.**
- Visszajelzés-figyelő, a TWINX admin „Visszajelzések” lista, választervezetek.
