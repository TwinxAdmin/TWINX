# TWINX AI ügynökség — döntési lap a találkozóra

> **TÖRTÉNETI DOKUMENTUM (2026-10-16).** A TWINX irányt váltott (D23, 2026-11-23): egyedi modul-gyártó, a kreditmodell megszűnik, a fejlesztői ág kerül előtérbe. Az ebben a lapban rögzített döntések (pl. „első éles ág") a döntési naplóban (`01-alap-es-szabalyok.md`, 7. szakasz) vannak nyilvántartva a későbbi módosításokkal együtt. **Új döntéshez ne ezt a lapot használd.** Az irány: `claude/00-iranyvaltas-D23.md`.

> Használat: menjetek végig a pontokon, jelöljétek a döntést. Utána a döntések a
> döntési naplóba kerülnek (az alap-dokumentumban), és onnan adható át a Code-nak fejlesztésre.
> Dátum: 2026-10-16 · Résztvevők: Márk + üzlettárs

---

## A) DÖNTENDŐ — ezek kellenek az induláshoz

### 1. Go / no-go: belevágunk-e most?
A 2. fázistól (az első valódi, dolgozó ügynök) **API-költség** van, ami a Claude MAX-előfizetésen **felül**, külön számla.
- ☐ Igen, indulunk (vállaljuk az API-költséget)
- ☐ Még nem, maradunk a tervezésnél
- *Megjegyzés: a 0–1. fázis (váz) már kész és ingyen fut; ez a döntés csak a fizetős, dolgozó részről szól.*

### 2. Havi költségkeret (spend limit)
Mennyit szánunk havonta a működésre? Két tétel: **API** (szöveg/kód) + **eszköz-kredit** (képgenerálás, pl. Higgsfield).
- ☐ API havi keret: __________ (javasolt induló plafon: alacsonyan, pl. pár tízezer Ft, és figyeljük)
- ☐ Eszköz-kredit havi keret: __________
- *A Console-ban beállítható kemény plafon, ami fölött leáll — érdemes élni vele.*

### 3. Első éles ág / prioritás
A dev-keretrendszer után melyik szakosodott ág legyen az első, amit élesítünk?
- ☐ TWINX-fejlesztés (folytatjuk, amit elkezdtünk)
- ☐ Kreatív/marketing ág (TWINX népszerűsítése)
- ☐ E-mail / szöveges ág
- *Ajánlás: egyszerre EGY ág legyen éles, végig validálva, mielőtt a következő jön.*
- *(A 2026-11-05-i döntés a partner ág lett, a 2026-11-23-i irányváltás (D23) után pedig a fejlesztői ág az előtérben.)*

### 4. Kreatív ág — hatókör és jóváhagyás
A TWINX-népszerűsítéshez: melyik tartalomtípusok legyenek az első sablonok, és ki hagyja jóvá a kimenő anyagot?
- Első sablonok (jelöljétek, mi ismétlődik tényleg): ☐ akciós/hír poszt ☐ modul-bemutató reels ☐ referencia/eredmény poszt ☐ landingre terelő hirdetés-variánsok ☐ egyéb: ______
- Ki a brand-jóváhagyó (mi megy ki): ☐ Márk ☐ üzlettárs ☐ közösen
- *Ajánlás: a sablonok megtervezése a munka 80%-a — kevés típussal induljunk, azt tesztelve.*

### 5. Hozzáférés és jogosultság
Milyen kulcsokat/fiókokat kap az ügynökség, és ki a számlatulajdonos?
- Érintett fiókok: Supabase, GitHub, Vercel, Higgsfield, social fiókok — ☐ melyikhez kap hozzáférést: ______
- Számla/kulcs tulajdonosa: ☐ Márk ☐ üzlettárs ☐ közös céges
- A **TWINX-repót érintő** változásnál ki a jóváhagyó: ☐ csak Márk ☐ termék-érintőnél az üzlettárs is
- *Alapszabály marad: minden kockázatos lépés „javasol → ember jóváhagyja".*

### 6. Megosztás / láthatóság
Az üzlettárs is lássa/használja a rendszert?
- ☐ Csak Márk használja egyelőre
- ☐ Az üzlettárs is lát egy felületet (pl. saját Telegram-hozzáférés, vagy egy-egy megosztott ügynök)
- *Ez a memória „scope" tervét érinti — jó most eldönteni, mert visszamenőleg nehéz beépíteni.*
- *(D23 után különösen fontos: Tibi a felmérések másik vezetője, és az ügyféladatokhoz ő is hozzáfér majd.)*

---

## B) VÁLASZTHATÓ — profibbá teszi, de az induláshoz NEM kell (3 pont)

### I. Külön minőségellenőrző (reviewer) ügynök
Egy független ügynök, ami átnézi a kész munkát (kód vagy kreatív), mielőtt Márk elé kerül — „második szempár" gépből.
- **Mit ad:** magasabb, egyenletesebb minőség, kevesebb hiba csúszik át.
- **Miért nem kell induláshoz:** kezdetben Márk a minőségellenőr; ez akkor éri meg, ha már sok a munka.

### II. Önfejlesztő hurok (\"dreaming\" + automata skill-gyártás)
A rendszer időközönként átnézi a saját munkáját, és javaslatot tesz új skillekre / a tudás rendszerezésére (heti konszolidáció, külső felderítés).
- **Mit ad:** a rendszer idővel egyre jobb és gyorsabb lesz, kevesebb kézi tanítással.
- **Miért nem kell induláshoz:** előbb legyen mit rendszerezni; üres rendszernél felesleges.

### III. Felhős telepítés / megoszthatóság
Egy bevált ügynök átköltöztetése a saját gépről felhőbe — így mindig elérhető (nem függ Márk gépétől), és biztonságosan megosztható (pl. az üzlettárssal, vagy később a termékben prémium szolgáltatásként).
- **Mit ad:** 0–24 elérhetőség, csapat-használat, és megnyitja a „prémium ügynök a weblapon" irányt.
- **Miért nem kell induláshoz:** a személyes dev-eszköznél a gépen futás elég; ez a skálázás lépése.

---

## Mi történik a döntések után
A meghozott döntéseket beírjuk a döntési naplóba (alap-dokumentum, 7. szakasz), és a három dokumentummal (alap + keretrendszer-spec + CLAUDE.md) plusz a megépített `twinx-agents` projekttel átadható a Code-nak fejlesztésre.
