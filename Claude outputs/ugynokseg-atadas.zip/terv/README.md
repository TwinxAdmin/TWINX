# TWINX tervek (ügynökség-export, 2026-11-23, D61-ig)

A `terv` mappa egészében kerül a repóba (`docs/terv/`), az `ai-ugynokseg` almappával együtt. Csak olvasható másolat. Rend: 26-egyuttmukodes-rendje.md. Irányadó: 00 és ai-ugynokseg/01. Kezdd az `ai-ugynokseg/11-ugynokseg-kovetkezo-feladatok.md` fájllal.
Az ai-ugynokseg/03, 06, 07, 08 történeti anyag (a partner ág szünetel). Nincs benne: a régi memória-export (kérésre).
