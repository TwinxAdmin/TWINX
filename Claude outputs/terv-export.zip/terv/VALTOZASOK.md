# VÁLTOZÁSOK (a tervező projekt vezeti; a repóban csak olvasható)

## 2026-11-24 – 3. export (döntések: D23–D70)
- Új dokumentum: `29-design-B-irany-terv.md` (D69, D70: a B arculat, design-tokenek, főoldal és kezdőlap megjelenése, a 6. lépés CODE-promptja).
- Új mappa: `design/` – a vizuális minta (`B-fooldal.dc.html`, `B-kezdolap.dc.html`), statikus HTML; csak mintának, nem bemásolásra.
- Módosult: `ai-ugynokseg/01` (D69, D70).
- Mit kell elolvasnia a fejlesztésnek: `29`, a `design/` két fájlja, `11` (tartalom), és az `01` D69–D70 bejegyzése.
- Az 5/b `/ingatlan` átirányítása várjon, amíg Márk jóvá nem hagyja az új főoldalt.

## 2026-11-24 – 2. export (döntések: D23–D68)
- A fejlesztés visszajelzése (a terv 11–23 lépései, élesben) átvezetve.
- Új dokumentum: `27-ingatlan-csomag-koltsegvedelme-terv.md` (D62) és `28-code-promptok-5-lepes.md` (az 5/a és 5/b CODE-prompt).
- Módosult: `ai-ugynokseg/01` (új döntések D62–D68; az irodai fiók 3. fázisa és az ÁSZF parkolt; megőrzési határidő ideiglenesen 90 nap), `ai-ugynokseg/04` (megvalósítási állapot és új buktatók), `25`, `26` (nyitott és parkolt lista, Márk teendői).
- Új döntések: D62 Ingatlan csomag keret (cégenként, egyszerű) · D63 kampányoldalak · D64 ÁSZF később AI-vázlat + jogász · D65 megőrzés 90 nap (ideiglenes) · D66 szövegek és korlátok (alapérték) · D67 irodai fiók 3. fázis parkolt · D68 átvezetett eltérések.
- Mit kell újraolvasnia a fejlesztésnek: `27`, `28` (5/a), `20` (a mechanika), `22` (3.A), és az `01` D62–D68 bejegyzései.
- Ütközésnél: a technikai tényekben a kód, a döntésekben a terv az irányadó.

## 2026-11-23 – 1. export (döntések: D23–D59)
- Első teljes export a `docs/terv/` mappának.
